SkillPath Backend — Setup
=========================

The Flask + database backend for SkillPath: user accounts, an admin role,
bookmarks, a 10-question assessment for every roadmap step, and
certificates.

FOLDER CONTENTS
---------------
app.py             the Flask API (database models, login, grading, admin routes)
seed_data.py       loads the skills, roadmap steps, topic boxes and questions
questions_data.py  the question bank: 10 questions for each of the 23 steps
setup.py           one-time setup: creates the database, admin account and all content
requirements.txt   Python packages needed


1. INSTALL  (run once)
-----------------------
Open a terminal in this folder. Type each command on its own line and
press Enter after each one:

    pip install -r requirements.txt

(If pip isn't recognised on Windows, use: python -m pip install -r requirements.txt)


2. CREATE THE DATABASE  (run once)
-----------------------------------
    python setup.py

This creates skillpath.db (a SQLite file in this folder), the admin
account, and loads all 5 skills, 23 steps, 98 topic boxes and 230
assessment questions.

    Admin login:   admin@skillpath.com
    Password:      admin123


3. RUN THE SERVER
------------------
    python app.py

Leave this running. The API is at http://127.0.0.1:5000
Quick check: http://127.0.0.1:5000/api/health should show {"status": "ok"}


4. ALREADY HAVE A skillpath.db FROM AN EARLIER VERSION?
--------------------------------------------------------
Run this once. It adds anything that is missing (topic boxes, the
assessment tables and questions) and never deletes or duplicates data.
Your users and bookmarks are kept:

    python seed_data.py

Then restart the server (python app.py).
Note: steps that were marked "reached" in the old version (before
assessments existed) are not carried over, because a step now counts as
reached only after its assessment is passed.


5. HOW ASSESSMENTS AND CERTIFICATES WORK
-----------------------------------------
- "Mark as reached" on a step starts that step's assessment:
  9 multiple-choice questions + 1 small program question.
- Pass mark: 70% (7 out of 10). Passing marks the step as reached.
  A learner can retake as often as they like; the best score is kept.
- The server never shows the correct answers until after a submission.
- Program questions are NEVER run on the server. The answer is checked
  against a list of requirements (each one has a plain-English label the
  learner sees). Comments are ignored. The model solution is shown after
  submitting.
- When a learner has passed every step of a skill, a certificate is
  issued automatically (one per learner per skill), with an ID such as
  SP-PYT-0002-B42F1A. Anyone can check an ID through the public
  verify endpoint or the "Verify a certificate" box on the website.
- A step that has no questions is skipped when deciding whether a
  certificate is earned, so an unfinished new step never blocks anyone.


6. THE ADMIN CONSOLE
---------------------
Sign in to the website with the admin account. An "Admin console" button
appears in the top bar. Learners never see it, and the server refuses
admin requests from learner accounts even if someone calls the API
directly.

  Overview     learners, assessments taken and pass rate, certificates
               issued, per-skill numbers, and the latest assessments
  Users        every account with steps passed / attempts / certificates.
               Make a learner an admin (or back), or delete a learner
               (their scores, bookmarks and certificates go with them).
               You can't demote or delete your own account.
  Content      add, edit and delete skills, roadmap steps (title, video,
               free certification link), topic boxes, and the assessment
               questions for each step. Changes are live for learners
               straight away.
  My account   change your password. Please change the starter password
               (admin123) the first time you sign in.

Everything the console does is also available as API calls:

  GET    /api/admin/stats                     numbers for the overview
  GET    /api/admin/users                     list accounts with activity
  PUT    /api/admin/users/<id>                {"role": "admin" | "user"}
  DELETE /api/admin/users/<id>                delete a learner
  POST   /api/admin/skills                    add a skill (key: lowercase letters, digits, - _)
  PUT    /api/admin/skills/<id>               edit a skill
  DELETE /api/admin/skills/<id>               delete a skill (and everything under it)
  POST   /api/admin/modules                   add a roadmap step
  PUT    /api/admin/modules/<id>              edit a roadmap step
  DELETE /api/admin/modules/<id>              delete a roadmap step
  POST   /api/admin/subtopics                 add a topic box
  PUT    /api/admin/subtopics/<id>            edit a topic box
  DELETE /api/admin/subtopics/<id>            delete a topic box
  GET    /api/admin/modules/<id>/questions    list a step's questions WITH answers
  POST   /api/admin/questions                 add a question
  PUT    /api/admin/questions/<id>            edit a question
  DELETE /api/admin/questions/<id>            delete a question
  POST   /api/change-password                 {old_password, new_password} (any signed-in user)

Adding a multiple-choice question (JSON body):
  {"module_id": 1, "kind": "mcq", "text": "Question?",
   "options": ["A", "B", "C", "D"], "answer_index": 2, "explanation": "Why."}

Adding a program question:
  {"module_id": 1, "kind": "code", "text": "Write ...", "language": "python",
   "starter": "", "solution": "model answer",
   "checks": [{"label": "Defines a function", "pattern": "def\\s+\\w+"}]}
  ("pattern" is a regular expression; every check must match.)


7. SWITCHING FROM SQLITE TO MYSQL  (optional)
----------------------------------------------
SQLite (the default) needs no setup. To use MySQL instead, once MySQL is
installed and an empty "skillpath" database exists:

    pip install pymysql

Then, in the same terminal and before running setup.py / app.py, set:

  Windows (PowerShell):
    $env:SKILLPATH_DATABASE_URL = "mysql+pymysql://root:yourpassword@localhost/skillpath"

  Mac/Linux:
    export SKILLPATH_DATABASE_URL="mysql+pymysql://root:yourpassword@localhost/skillpath"


8. THE WEBSITE
---------------
The React website (skillpath-frontend) loads everything from this API.
Start this backend first, then the website. Open the website at
http://localhost:5173 or http://127.0.0.1:5173 — either works. If the
backend is not running, the website shows a "can't reach the server"
banner.


API ENDPOINT SUMMARY
---------------------
Auth:
  POST /api/register                       {name, email, password}
  POST /api/login                          {email, password}
  POST /api/logout
  GET  /api/me

Public:
  GET  /api/skills
  GET  /api/skills/<key>                   steps, topic boxes, video + certification links
  GET  /api/certificates/verify/<code>     check a certificate ID

Any signed-in user:
  POST /api/change-password                {old_password, new_password}

Learner (must be logged in):
  GET  /api/modules/<id>/assessment        the questions (no answers)
  POST /api/modules/<id>/assessment        {answers: {"<question id>": option index or code text}}
  GET  /api/results                        best score / attempts for each step
  GET  /api/progress                       ids of steps reached
  GET  /api/certificates                   certificates earned
  GET  /api/bookmarks
  POST /api/bookmarks/<module_id>          toggles a bookmark
