SkillPath — Full Project Submission
====================================

This folder has two parts. Both need to be running at the SAME TIME, each
in its own terminal.

    skillpath-backend/    -> the server (Flask + database)
    skillpath-frontend/   -> the website (React), already fully configured


HOW TO RUN THIS (do these in order)
------------------------------------

STEP 1 — Start the backend
  Open a terminal inside skillpath-backend, then run:

      pip install -r requirements.txt
      python setup.py
      python app.py

  "setup.py" only needs to be run ONCE — it creates the database, an
  admin account, and loads all the skill roadmaps. After that, just
  "python app.py" starts the server. Leave this terminal running.

  Admin login (for testing the admin role):
      email:    admin@skillpath.com
      password: admin123


STEP 2 — Start the frontend
  Open a SECOND, separate terminal inside skillpath-frontend, then run:

      npm install
      npm run dev

  This will print a URL, usually http://localhost:5173/
  Leave this terminal running too.


STEP 3 — Open it
  Open the printed URL (http://localhost:5173/) in a browser.
  Try searching a skill (e.g. "Python"), creating an account, clicking a
  roadmap step to see its detail panel, marking it reached, and
  bookmarking it.


IMPORTANT
----------
Both terminals must stay open and running at the same time — the
website (frontend) depends on the server (backend) to load any content.
If you see a message on the site saying it can't reach the server, it
means the backend terminal isn't running.


WHAT THIS PROJECT IS
---------------------
SkillPath — a free skill-learning roadmap platform. A user searches a
skill (Python, Data Science, AWS, Web Development, or Cybersecurity)
and gets a roadmap drawn like roadmap.sh: a main path of steps, with
smaller topic boxes branching off each step. Click any box to see its
details and a free certification link. The free YouTube videos for a
skill are in a separate "Videos" tab.

ASSESSMENTS AND CERTIFICATES
  - "Mark as reached" on a step starts a 10-question check on that
    step's topic: 9 multiple-choice questions and 1 small program
    question. Passing (7 out of 10) marks the step as reached. The
    learner sees the correct answers and explanations afterwards and
    can retake as often as they like.
  - Program questions are not run; the answer is checked against a
    list of requirements shown to the learner, and a model solution is
    revealed afterwards.
  - When every step of a skill has been passed, the learner earns a
    SkillPath certificate (printable as a PDF) with a unique ID. Anyone
    can verify an ID using the "Verify a certificate" box.
  - 230 questions in total (23 steps x 10).

Users create an account; scores, progress, bookmarks and certificates
are saved per account in the database.

ADMIN CONSOLE
  Sign in with the admin account (admin@skillpath.com / admin123) and an
  "Admin console" button appears in the top bar. Learners never see it.
  It has four tabs:
    Overview    learners, assessments taken, pass rate, certificates
    Users       see every account; make someone an admin, or delete a learner
    Content     add / edit / delete skills, roadmap steps, topic boxes and
                assessment questions (live for learners straight away)
    My account  change the admin password

Tech stack: React (frontend), Flask + SQLAlchemy (backend), SQLite
(database — swappable to MySQL, see skillpath-backend/README.txt),
YouTube and free certification providers for resources.
